# Projeto-EstacioSports
Curso: Ciência da Computação <br>
Trabalho da disciplina --- Desenvolvimento web em HTML5, CSS, JAVASCRIPT e PHP   + banco de dados (MYSQL) <br>
Feitos por:  <i>Nathan Silva, Lucas Duarte e Gleydson Ribeiro</i> <br>
Professor: <i>Henrique Mota</i> 

 - Projeto foi hospedado na 000webhost ( Link abaixo )  <br>
<b>SITE PRINCIPAL:</b> https://websiteestacio.000webhostapp.com/  <br>
<b>AGENDAMENTO:</b>  https://estaciosports.000webhostapp.com/ <br>
<br>

![Frame 1](https://github.com/Dev-nathansilva/Projeto-EstacioSports/assets/124079997/0fe34775-64e9-44e9-9bd1-671c355d2960)
